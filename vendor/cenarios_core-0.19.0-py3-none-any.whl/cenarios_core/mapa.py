"""Mapa coroplético dos painéis Cenários: escala, enquadramento e o spec do deck.

Desenhado com **pydeck**, servido pelo componente de `mapa_componente`. Veio
do tbpe em 14/out/2026, com as correções que estavam presas em cada painel —
o NaN do DFTB, os cortes repetidos do hansepe, as ilhas do tbpe — e os
recursos que cada um inventou à parte (`notas`, `faixa_realcada`).

**Não sabe de território.** A chave, a coluna de nome e a camada vêm de quem
chama; a ilha oceânica é detectada pela geometria (`limites_uteis`), não por
código de município. O que é **casca** de cada painel — cores de divisa e de
realce — entra por `Contornos`.

A escala tem três classificações (`CLASSIFICACOES`): quebras naturais,
quantis e escala fixa com cortes declarados no pacote da doença. O porquê de
cada uma está na docstring da função. O histórico do Plotly ao pydeck está em
`docs/mapa-clique.md` do tbpe.
"""

from __future__ import annotations

from dataclasses import dataclass

import math

import numpy as np
import pandas as pd

#: Número de classes da escala. Valor do original.
CLASSES = 6

#: Cor de quem não tem dado. Precisa ser distinguível de qualquer tom da rampa.
SEM_DADO = "#F3F4F6"

#: Altura do mapa, em pixels. O painel reserva `ALTURA_MIN_MAPA`.
#:
#: Casada com `LARGURA_PAINEL`, não escolhida à parte. O Brasil é quase
#: quadrado — 45,1 graus de largura por 41,2 em Mercator — e o enquadramento
#: pega o menor dos dois ajustes, então altura de menos faz a altura virar o
#: teto e a largura nova ser desperdiçada: com 580x460 o país saía 504x460,
#: preso pela altura. 530 é o que 580 de largura pede (580 x 41,2 / 45,1), e o
#: Brasil desenha 580x529.
#:
#: Eram 460, casados com os 430 de largura de quando a barra lateral existia.
#: Baixar mais aperta o ranking, que divide a linha e recebe `ALTURA - 46`.
ALTURA = 530

ROTULO_SEM_DADO = "sem dado"

def _caracteres(textos) -> tuple[str, ...]:
    """Conjunto de caracteres para o atlas de fonte de uma camada de texto.

    O `TextLayer` do deck.gl monta o atlas com um conjunto fixo, e o que fica
    fora dele não vira caractere errado: vira **espaço em branco**. "Maués"
    aparecia como "Mau s", e o defeito só se manifesta em nome acentuado — que
    é a maioria dos municípios brasileiros.

    **Lista explícita, e não `"auto"`.** O deck aceita a string `"auto"`, mas
    o pydeck a converte em acessor de dado — vira `@@=auto`, o deck procura um
    campo chamado `auto` em cada linha, não acha, e cai no conjunto padrão. É
    a mesma armadilha que já custou o `size_units="pixels"` virar `@@=pixels`
    e fazer o texto do mapa escalar junto com o zoom.

    **Tupla, e não lista.** O pydeck converte lista em acessor do mesmo jeito
    que converte string: `["a", "é"]` vira `@@=[a, é]`. Tupla ele serializa
    como array JSON, que é o que o deck.gl espera. Testadas as quatro formas.

    Montado a partir do texto que a camada de fato desenha, então o atlas fica
    do tamanho do necessário.
    """
    return tuple(sorted({c for t in textos for c in str(t)}))


@dataclass(frozen=True, slots=True)
class Escala:
    """Classes de uma escala: cortes, rótulo e cor de cada uma.

    ``fechada_a_esquerda`` diz de que lado fica o valor que cai **em cima**
    de um corte. ``False`` é o intervalo ``(a, b]`` do pandas: 40,0 entra na
    classe de baixo. ``True`` é ``[a, b)``, como a régua do Ministério se
    escreve — "Médio 2,00 a 9,99": 2,00 é Médio, não Baixo. Só a régua
    oficial (:func:`escala_fixa` com ``nomes``) liga isso.

    ``categorica`` é a escala de :func:`escala_categorica`: sem cortes, cada
    rótulo é uma categoria do próprio dado ("Prioridade alta", "Hotspot
    persistente"), e :func:`classificar` devolve o valor em vez de cortá-lo.
    """

    cortes: list[float]
    rotulos: list[str]
    cores: dict[str, str]
    fechada_a_esquerda: bool = False
    categorica: bool = False

    @property
    def classes(self) -> int:
        return len(self.rotulos)


def _formatar(valor: float, decimais: int) -> str:
    texto = f"{valor:,.{decimais}f}"
    return texto.replace(",", "\x00").replace(".", ",").replace("\x00", ".")


def _quebras_naturais(v, classes: int, iteracoes: int = 50) -> list[float]:
    """Cortes que minimizam a variancia dentro de cada classe (Jenks).

    k-medias em uma dimensao, partindo dos quantis e iterando ate estabilizar.
    Deterministico: mesma entrada, mesmos cortes.
    """
    v = np.sort(np.asarray(v, dtype=float))
    centros = np.quantile(v, np.linspace(0, 1, classes + 2)[1:-1])
    for _ in range(iteracoes):
        rotulo = np.abs(v[:, None] - centros[None, :]).argmin(1)
        novos = np.array(
            [
                v[rotulo == i].mean() if (rotulo == i).any() else centros[i]
                for i in range(classes)
            ]
        )
        if np.allclose(novos, centros):
            break
        centros = np.sort(novos)
    meios = [(centros[i] + centros[i + 1]) / 2 for i in range(classes - 1)]
    return sorted(set([float(v[0]), *map(float, meios), float(v[-1])]))


def escala_natural(
    valores: pd.Series, rampa: list[str], classes: int = CLASSES, decimais: int = 1
) -> Escala:
    """Divide os valores em classes por **quebras naturais**.

    Era por quantis, classes de igual frequencia, herdado do painel em R.
    Trocou em 24/ago/2026 porque a incidencia tem cauda longa e o quantil
    comprime justamente o topo, que e onde a vigilancia olha: em Pernambuco,
    **29 municipios dividiam a mesma cor cobrindo de 59 a 445 por 100 mil** --
    Itapissuma e Goiana pintados iguais com seis vezes de diferenca.

    Medido pelo GVF, que e quanto da variancia dos dados a classificacao
    explica -- 1,0 seria perfeito:

    ==========  ========  ==========  ========
    recorte     quantil   naturais    iguais
    ==========  ========  ==========  ========
    Brasil         0,895       0,958     0,962
    PE             0,463       0,964     0,823
    MG             0,791       0,939     0,916
    ==========  ========  ==========  ========

    Intervalos iguais ganham por pouco no Brasil e perdem feio em PE, e ainda
    empilham quase tudo na classe de baixo -- o defeito espelhado. Quebras
    naturais e o unico que vai bem nos tres.

    Custa 2,5 ms em MG, o maior recorte, contra 0,1 do quantil. Cabe no
    orcamento de 300 ms por interacao com folga; ver docs/performance.md.

    Cortes repetidos sao colapsados: quando mais da metade dos municipios tem
    zero caso -- comum em recortes pequenos -- varios cortes caem no mesmo
    numero e produziriam classes vazias.
    """
    limpos = pd.to_numeric(valores, errors="coerce").dropna()
    limpos = limpos[np.isfinite(limpos)]
    if limpos.empty:
        return Escala(cortes=[], rotulos=[], cores={ROTULO_SEM_DADO: SEM_DADO})

    if limpos.nunique() <= classes:
        cortes = sorted(set(limpos.tolist()))
        if len(cortes) > 1:
            cortes = cortes[:1] + [
                (cortes[i] + cortes[i + 1]) / 2 for i in range(len(cortes) - 1)
            ] + cortes[-1:]
    else:
        cortes = _quebras_naturais(limpos.to_numpy(), classes)
    # O mesmo montador dos outros dois métodos: os três diferem em **onde
    # cortar**, e rótulo e cor se montam igual. Enquanto isto estava
    # duplicado aqui, a proteção contra cortes que se escrevem iguais não
    # valia para quebras naturais (o hansepe achou o mesmo em `be0a653`).
    return _montar(cortes, rampa, decimais)


#: Como o mapa reparte os valores em classes de cor.
#:
#: As três convivem porque respondem a exigências diferentes, e nenhuma vence
#: nas três ao mesmo tempo:
#:
#: ==========  ==============  ==================  =====================
#: método      ajuste (GVF)    classes iguais?     comparável entre anos?
#: ==========  ==============  ==================  =====================
#: NATURAL          0,842            não                   não
#: QUARTIL          0,239            sim                   não
#: FIXA             varia            não                   **sim**
#: ==========  ==============  ==================  =====================
#:
#: Medido na incidência por bairro de Recife em 2023, 94 bairros.
CLASSIFICACOES = ("NATURAL", "QUARTIL", "FIXA")

ROTULO_CLASSIFICACAO = {
    "NATURAL": "Quebras naturais",
    "QUARTIL": "Quartis",
    "FIXA": "Escala fixa",
}


def _montar(
    cortes: list[float], rampa: list[str], decimais: int, abertas: bool = False
) -> Escala:
    """Monta a `Escala` a partir dos cortes já decididos.

    Extraído de `escala_natural` quando os outros dois métodos entraram: os
    três diferem só em **onde cortar**, e rótulo e cor se montam igual. Deixar
    isso duplicado seria como uma classificação ganhar um rótulo diferente da
    outra sem ninguém decidir.

    ``abertas`` é para a escala fixa: a primeira classe se lê "< 2" e a
    última "≥ 40", como a régua oficial se escreve — "40,0 a 112,8" mistura o
    corte declarado com o máximo observado do ano, que é só o teto do `cut`.
    """
    cortes = [float(c) for c in cortes]
    # Cortes que se **escrevem** iguais viram um só.
    #
    # Achado no hansepe (`be0a653`, 09/out/2026): duas regiões de saúde do
    # Agreste com 2,7765 e 2,7878 são "2,8" as duas, o quintil montava classes
    # "2,8 a 2,8" e o `cut` recusa rótulos repetidos — o mapa caía com
    # `ValueError`. Classe que não se distingue na legenda não é classe.
    #
    # **As pontas ficam.** O primeiro corte é o mínimo e o último é o máximo
    # da série, que aqui é o teto do `cut` — o hansepe pode guardar o primeiro
    # de cada repetição porque troca o último limite por infinito. Por isso,
    # na repetição, o corte novo **substitui** o anterior, salvo quando o
    # anterior é o mínimo: o rótulo não muda e o município mais alto continua
    # dentro de uma classe.
    if cortes:
        distintos = [cortes[0]]
        for corte in cortes[1:]:
            if _formatar(corte, decimais) != _formatar(distintos[-1], decimais):
                distintos.append(corte)
            elif len(distintos) > 1:
                distintos[-1] = corte
        if len(distintos) == 1 and len(cortes) > 1:
            # Tudo se escreve igual: uma classe só, mas cobrindo do mínimo ao
            # máximo, não um ponto que deixa o resto de fora do `cut`.
            rotulo = _formatar(distintos[0], decimais)
            return Escala(
                cortes=[cortes[0], cortes[-1]],
                rotulos=[rotulo],
                cores={rotulo: rampa[len(rampa) // 2], ROTULO_SEM_DADO: SEM_DADO},
            )
        cortes = distintos
    if len(cortes) < 2:
        unico = cortes[0] if cortes else 0.0
        rotulo = _formatar(unico, decimais)
        return Escala(
            cortes=[unico, unico],
            rotulos=[rotulo],
            cores={rotulo: rampa[len(rampa) // 2], ROTULO_SEM_DADO: SEM_DADO},
        )

    usadas = len(cortes) - 1
    indices = np.linspace(0, len(rampa) - 1, usadas).round().astype(int)
    tons = [rampa[i] for i in indices]
    def faixa(i: int) -> str:
        de, ate = _formatar(cortes[i], decimais), _formatar(cortes[i + 1], decimais)
        if abertas and i == 0:
            return f"< {ate}"
        if abertas and i == usadas - 1:
            return f"≥ {de}"
        return f"{de} a {ate}"

    rotulos = [faixa(i) for i in range(usadas)]
    cores = dict(zip(rotulos, tons, strict=True))
    cores[ROTULO_SEM_DADO] = SEM_DADO
    return Escala(cortes=cortes, rotulos=rotulos, cores=cores)


#: Quantas classes de igual frequência. Cinco, e não quatro: o painel de
#: origem reparte os 185 municípios de PE em **quintis** (37 por classe), e a
#: paridade visual pede a mesma régua. O nome do método continua "QUARTIL"
#: no contrato para não quebrar o RecifeTB, que usa quatro.
QUANTIS = 5


def escala_quartis(
    valores: pd.Series, rampa: list[str], decimais: int = 1, quantis: int = QUANTIS
) -> Escala:
    """Classes de igual **frequência** — a mesma fração das geografias em cada.

    É o que a vigilância costuma pedir por ser fácil de explicar: "este bairro
    está no quarto superior". A conta é o percentil 25, 50 e 75 da própria
    série, com interpolação linear.

    **O custo aparece quando a cauda é longa**, e a de Recife é: em 2023 a
    classe de cima vai de 202 a 3.610, dezessete vezes de diferença numa cor
    só — Boa Viagem e o bairro do Recife ficam indistinguíveis. Medido pelo
    GVF, quanto da variância a classificação explica: 0,239 contra 0,842 das
    quebras naturais.

    Fica disponível porque a escolha é de quem lê o mapa, não de quem o
    escreve — e porque "um quarto dos bairros" é um recorte legítimo mesmo
    quando ajusta mal.
    """
    limpos = pd.to_numeric(valores, errors="coerce").dropna()
    if limpos.empty:
        return _montar([], rampa, decimais)
    cortes = list(np.quantile(limpos.to_numpy(), np.linspace(0.0, 1.0, quantis + 1)))
    # Cortes colapsados viram uma classe só: acontece quando mais de um quarto
    # das geografias tem o mesmo valor, tipicamente zero.
    #
    # **Sem arredondar.** Arredondar para dez casas parecia inofensivo e
    # excluía o mínimo: com o Distrito Sanitário III em 72,2660471147612, o
    # corte inferior virava 72,2660471148 — maior que o próprio valor —, o
    # `pd.cut` devolvia nulo e o distrito saía pintado de "sem dado", branco,
    # justamente o que mais chama atenção num mapa. Os quantis já devolvem
    # floats idênticos quando colapsam, então `dict.fromkeys` basta para
    # deduplicar sem tocar no valor.
    cortes = sorted(dict.fromkeys(float(c) for c in cortes))
    return _montar(cortes, rampa, decimais)


def _montar_regua(
    cortes: list[float], rampa: list[str], nomes: tuple[str, ...], casas: int
) -> Escala:
    """A régua oficial — a do Ministério, no hansepe —, idêntica em todo
    recorte e em todo ano.

    **Não olha os dados.** As classes são as declaradas, todas, sempre. Na
    versão que derivava a última classe do máximo observado, ela só existia
    quando algum valor passava do teto: nas macrorregiões de 2025 a legenda
    dizia "≥ 20 Muito alto" e a classe Hiperendêmico sumia, e quem olhasse
    concluiria que o estado não a tem.

    Os limites têm infinito nas pontas porque é assim que a régua se lê:
    "< 2" não tem piso e "≥ 40" não tem teto. E a escala sai
    ``fechada_a_esquerda``: 2,00 é "Médio 2,00 a 9,99", não "Baixo".

    O rótulo reproduz a citação do boletim: a classe que vai de 2 até antes
    de 10 se escreve "2,00 a 9,99", e não "2 a 10" — escrita assim, o 10
    aparecia em duas faixas da legenda (a equipe parceira do hansepe
    apontou). ``casas`` é com quantas decimais o documento escreve a régua,
    que não é a precisão do dado nem a dos cortes: o boletim de hanseníase
    declara 9,99 para as taxas e 89,9 para a cura.
    """
    inicios = [float(c) for c in cortes[1 : len(nomes)]]
    indices = np.linspace(0, len(rampa) - 1, len(nomes)).round().astype(int)
    tons = [rampa[i] for i in indices]
    passo = 10.0 ** -casas

    def rotulo(i: int) -> str:
        if i == 0:
            return f"< {_formatar(inicios[0], casas)}"
        if i == len(nomes) - 1:
            return f"≥ {_formatar(inicios[-1], casas)}"
        return (
            f"{_formatar(inicios[i - 1], casas)} a "
            f"{_formatar(inicios[i] - passo, casas)}"
        )

    rotulos = [rotulo(i) for i in range(len(nomes))]
    cores = dict(zip(rotulos, tons, strict=True))
    cores[ROTULO_SEM_DADO] = SEM_DADO
    return Escala(
        cortes=[-math.inf, *inicios, math.inf], rotulos=rotulos, cores=cores,
        fechada_a_esquerda=True,
    )


def escala_fixa(
    valores: pd.Series,
    rampa: list[str],
    cortes: list[float],
    decimais: int = 1,
    *,
    nomes: tuple[str, ...] | None = None,
    casas_regua: int = 2,
) -> Escala:
    """Cortes declarados de fora, iguais em todo ano.

    **É a única das três que torna dois anos comparáveis.** Os outros métodos
    recalculam os limites a partir dos dados do ano, então a régua muda debaixo
    do mapa: medido em Recife, a segunda quebra natural foi 93 em 2021, 105 em
    2022 e 101 em 2023. Um bairro pode escurecer de um ano para o outro tendo
    incidência menor.

    O preço é que os cortes precisam ser **decididos**, e uma decisão ruim
    entrega um mapa de uma cor só. Por isso eles vivem no *disease pack*, com a
    âncora de cada um escrita ao lado — ver `CORTES_FIXOS` em
    `src/doencas/tuberculose.py`.

    A última classe é **aberta**: quando a série passa do teto declarado, o
    máximo entra como corte **a mais**, e não no lugar do último. Substituir
    apagava a âncora de cima — com cortes até 624 e máximo em 3.610, a legenda
    exibia "312 a 3.610" e o 4× Recife desaparecia. Acrescentando, ela exibe
    "312 a 624" e "624 a 3.610", que é o que se quis declarar.
    """
    # **Duas escalas fixas.** Com ``nomes``, os cortes são régua oficial e a
    # escala não consulta os dados — :func:`_montar_regua`; é o que o hansepe
    # usa. Sem eles, é a escala ancorada do tbpe e do RecifeTB: a última
    # classe só aparece quando há valor nela. Qual das duas a TB deve usar
    # está em aberto (README).
    if nomes:
        return _montar_regua(list(cortes), rampa, nomes, casas_regua)

    limpos = pd.to_numeric(valores, errors="coerce").dropna()
    limites = sorted(float(c) for c in cortes)
    # Cortes declarados inteiros se escrevem inteiros: "< 2", não "< 2,0".
    # Os de 0–14 (0,5 · 2,5) continuam com a casa decimal.
    if all(float(c).is_integer() for c in limites):
        decimais = 0
    if limpos.empty or len(limites) < 2:
        return _montar(limites, rampa, decimais, abertas=True)

    teto = float(limpos.max())
    if teto > limites[-1]:
        limites = [*limites, teto]
    piso = float(limpos.min())
    if piso < limites[0]:
        limites = [piso, *limites[1:]]
    return _montar(limites, rampa, decimais, abertas=True)


def escala_categorica(cores: dict[str, str]) -> Escala:
    """Escala de categorias: cada valor do dado é uma classe, com a sua cor.

    Para o que já chega classificado — a classe de prioridade, o hotspot e a
    tendência da Análise de Mortalidade (tbbrasil). A **ordem do dicionário é
    a da legenda**: quem chama decide, do mais grave ao mais brando ou como o
    estudo apresenta. Valor fora do dicionário cai em "sem dado", como o
    ausente — melhor a legenda dizer que não sabe do que pintar com cor de
    outra classe.
    """
    if not cores:
        raise ValueError("escala categórica sem categorias")
    return Escala(
        cortes=[],
        rotulos=list(cores),
        cores={**cores, ROTULO_SEM_DADO: SEM_DADO},
        categorica=True,
    )


def escala(
    valores: pd.Series,
    rampa: list[str],
    *,
    categorias: dict[str, str] | None = None,
    metodo: str = "NATURAL",
    cortes_fixos: list[float] | None = None,
    nomes_fixos: tuple[str, ...] | None = None,
    casas_regua: int = 2,
    classes: int = CLASSES,
    decimais: int = 1,
    quantis: int = QUANTIS,
) -> Escala:
    """Despacha para o método de classificação pedido.

    ``cortes_fixos`` só é usado por ``FIXA``; sem ele, o método cai em
    ``NATURAL`` em vez de estourar. Mapa sem cor por falta de configuração é
    pior que mapa classificado de outro jeito.

    ``quantis`` é quantas classes de igual frequência ``QUARTIL`` monta: cinco
    em PE (os quintis do painel em R), quatro no RecifeTB.

    ``categorias`` (categoria → cor) manda em tudo: com ela a escala é
    categórica (:func:`escala_categorica`) e ``metodo`` não se aplica.
    """
    if categorias:
        return escala_categorica(categorias)
    alvo = str(metodo or "NATURAL").strip().upper()
    if alvo not in CLASSIFICACOES:
        raise ValueError(
            f"Classificação desconhecida: {metodo!r}. Esperado {CLASSIFICACOES}."
        )
    if alvo == "QUARTIL":
        return escala_quartis(valores, rampa, decimais, quantis=quantis)
    if alvo == "FIXA" and cortes_fixos:
        return escala_fixa(
            valores, rampa, list(cortes_fixos), decimais,
            nomes=nomes_fixos, casas_regua=casas_regua,
        )
    return escala_natural(valores, rampa, classes=classes, decimais=decimais)


def classificar(valores: pd.Series, escala: Escala) -> pd.Series:
    """Rótulo da classe de cada valor. Ausente e não-finito viram "sem dado"."""
    if escala.categorica:
        texto = valores.astype(object)
        return texto.where(texto.isin(escala.rotulos), ROTULO_SEM_DADO)
    numeros = pd.to_numeric(valores, errors="coerce")
    if not escala.rotulos:
        return pd.Series([ROTULO_SEM_DADO] * len(numeros), index=numeros.index)

    if escala.fechada_a_esquerda:
        # A régua oficial: `[a, b)`, e as pontas já são infinitas, então o
        # município mais alto do ano não fica fora da última classe (hansepe,
        # `f7ed32a`).
        faixas = pd.cut(
            numeros, bins=escala.cortes, labels=escala.rotulos, right=False,
            duplicates="drop",
        )
    else:
        # `cut` não inclui o limite inferior da primeira classe;
        # `include_lowest` resolve, e o `duplicates` cobre cortes colapsados.
        faixas = pd.cut(
            numeros,
            bins=escala.cortes,
            labels=escala.rotulos,
            include_lowest=True,
            duplicates="drop",
        )
    return faixas.astype(object).where(faixas.notna(), ROTULO_SEM_DADO)


def _mercator(lat: float) -> float:
    """Latitude em graus de Mercator, na mesma escala da longitude.

    É o que permite comparar a extensão vertical com a horizontal: no
    Mercator um grau de latitude ocupa mais pixels quanto mais longe do
    equador, e o Brasil cobre de -33° a +5°.
    """
    limitada = max(-85.0, min(85.0, float(lat)))
    radianos = np.radians(limitada)
    return float(np.degrees(np.log(np.tan(np.pi / 4 + radianos / 2))))


def _mercator_inverso(y: float) -> float:
    """Volta de graus de Mercator para latitude."""
    radianos = np.radians(float(y))
    return float(np.degrees(2 * np.arctan(np.exp(radianos)) - np.pi / 2))


#: Largura assumida do painel do mapa, em pixels — o **pior caso**, não o
#: comum. A altura é :data:`ALTURA`, e as duas andam juntas.
#:
#: O Streamlit não informa ao servidor a largura da janela, então o zoom é
#: calculado contra um número fixo enquanto a coluna real varia. Medido no
#: navegador, a coluna é `(janela - 106) / 2` — 80px de respiro da página, 16
#: do vão entre as colunas e ~10 da barra de rolagem:
#:
#: ===========  ======
#: janela       coluna
#: ===========  ======
#: 1280            587
#: 1366            630
#: 1536            715
#: 1920            907
#: ===========  ======
#:
#: Errar para cima **corta a geometria**: a 1280 o Acre saía pela borda
#: esquerda. Errar para baixo só deixa margem. Entre um mapa incompleto e um
#: mapa pequeno, o incompleto é pior num painel de vigilância — margem se vê,
#: recorte não.
#:
#: 580 cobre qualquer janela a partir de 1266px, que é o alvo do projeto.
#: Eram 430, o que sobrava depois de a barra lateral de 300px comer a tela;
#: sem ela, a mesma janela de 1280 dá 587.
#:
#: O preço continua sendo margem em telas largas — a 1536 sobram 135px em
#: volta do mapa. Isto move o pior caso, não elimina o problema: a correção de
#: verdade é medir a largura no cliente e devolvê-la ao servidor, ver
#: `docs/deploy.md`.
LARGURA_PAINEL = 580


#: Fração da área total que define o "corpo" da camada. O que sobra são
#: partes minúsculas — ilhas oceânicas, no nosso caso.
COBERTURA_CORPO = 0.999

#: Quantos graus uma parte precisa estar fora do corpo para contar como
#: afastada. 1° são cerca de 110 km: mais que qualquer ilha costeira e muito
#: menos que Fernando de Noronha (4,5°) ou Trindade (5,9°).
FOLGA_AFASTADA = 1.0

#: Onde e de que tamanho fica o quadro da ilha, em fracao do enquadramento.
#:
#: Canto superior direito porque as ilhas brasileiras ficam a leste, e o olho
#: procura no lado de onde elas vieram. A ilha e escalada para ocupar
#: `DESTAQUE_TAMANHO` da largura do quadro principal -- Fernando de Noronha
#: tem 17 km2 contra os 98 mil de Pernambuco, entao em escala real ela e menor
#: que um pixel.
DESTAQUE_TAMANHO = 0.11
DESTAQUE_MARGEM = 0.02

_LIMITES: dict[tuple, tuple] = {}


def limites_uteis(camada) -> tuple[tuple[float, float, float, float], list]:
    """Retângulo de enquadramento ignorando ilhas oceânicas, e quem elas são.

    O ``total_bounds`` cru é dominado por pedaços de terra longe de tudo, e o
    enquadramento é calculado sobre ele — então o território que se quer ver
    encolhe para caber junto com uma ilha de 17 km². Medido:

    ==================  =========  ==========
    camada              cru        útil
    ==================  =========  ==========
    Brasil (27 UFs)     45,1°      39,2°
    PE (185 municípios)  9,0°       6,6°
    MG, SP              iguais     iguais
    ==================  =========  ==========

    No Brasil quem estica são **Trindade e Martim Vaz**, ilhas do Espírito
    Santo a 1.100 km da costa; em PE, **Fernando de Noronha**. O país inteiro
    desenhava 13% menor por causa de duas ilhas onde ninguém mora.

    Devolve também a lista de índices das feições que ficaram **inteiramente**
    fora — só essas somem da tela e precisam de um destaque. Trindade não
    entra na lista: ela é parte do Espírito Santo, que continua visível pelo
    continente.
    """
    import warnings

    import numpy as np

    chave = (len(camada), tuple(round(v, 4) for v in camada.total_bounds))
    if chave in _LIMITES:
        return _LIMITES[chave]

    partes = camada.geometry.explode(index_parts=False)
    # `area` em graus avisa que não é área de verdade, e não precisa ser: só
    # serve para ordenar partes da mesma camada, e a ordem é a mesma em
    # qualquer projeção razoável. Reprojetar 5.571 municípios a cada mapa
    # custaria mais que tudo o que esta função faz.
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*geographic CRS.*")
        areas = partes.area.to_numpy()
    ordem = np.argsort(areas)[::-1]
    corte = int(np.searchsorted(np.cumsum(areas[ordem]) / areas.sum(), COBERTURA_CORPO))
    corpo = partes.iloc[ordem[: corte + 1]]

    # O retângulo do corpo serve só para medir distância. Devolver ele seria
    # cortar território: em São Paulo, as ilhas costeiras de Cananéia caem no
    # rabo de 0,1% da área e ficariam de fora por 0,046° — perto demais para
    # serem "afastadas", e ainda assim recortadas. O que vale é o retângulo de
    # tudo **menos** as partes distantes.
    cx0, cy0, cx1, cy1 = (float(v) for v in corpo.total_bounds)
    b = partes.bounds
    distante = (
        (b.minx < cx0 - FOLGA_AFASTADA)
        | (b.maxx > cx1 + FOLGA_AFASTADA)
        | (b.miny < cy0 - FOLGA_AFASTADA)
        | (b.maxy > cy1 + FOLGA_AFASTADA)
    )
    fora = partes.index[distante]
    xmin, ymin, xmax, ymax = (float(v) for v in partes[~distante].total_bounds)
    # Uma feição só some da tela se **nenhuma** parte dela ficou no corpo.
    dentro = set(corpo.index)
    inteiramente_fora = [i for i in dict.fromkeys(fora) if i not in dentro]

    resultado = ((xmin, ymin, xmax, ymax), inteiramente_fora)
    _LIMITES[chave] = resultado
    return resultado


def extensao_visivel(limites, largura=None, altura=None):
    """Retangulo que o painel mostra, que e maior que o dos dados.

    `enquadrar` faz o bounding box caber, e sobra margem no eixo que nao
    limitou. Pernambuco tem 6,6 graus de largura por 1,7 de altura: cabe pela
    largura, e restam quatro graus de ceu e mar acima e abaixo.

    E nessa margem que o quadro da ilha vai, e nao no canto do bounding box --
    ali ele cairia em cima da costa nordeste do proprio estado.
    """
    largura = LARGURA_PAINEL if largura is None else largura
    altura = ALTURA if altura is None else altura

    xmin, ymin, xmax, ymax = limites
    dx = xmax - xmin
    dy = abs(_mercator(ymax) - _mercator(ymin))
    escalas = [largura / dx] if dx > 0 else []
    if dy > 0:
        escalas.append(altura / dy)
    if not escalas:
        return limites
    px_por_grau = min(escalas)

    meia_x = largura / px_por_grau / 2
    meia_y = altura / px_por_grau / 2
    cx = (xmin + xmax) / 2
    cy_merc = (_mercator(ymin) + _mercator(ymax)) / 2
    return (
        cx - meia_x,
        _mercator_inverso(cy_merc - meia_y),
        cx + meia_x,
        _mercator_inverso(cy_merc + meia_y),
    )


#: Quantas vezes o municipio destacado cabe na largura enquadrada.
#:
#: 5 e nao 1: enquadrar so o municipio responde "como ele e por dentro", e a
#: pergunta do destaque e "onde ele fica". Com cinco vezes, os vizinhos
#: aparecem e da para se localizar sem perder o municipio de vista.
FOCO_VIZINHANCA = 5

#: Piso do enquadramento, como fracao do recorte inteiro. Sem ele, um
#: municipio de 8 km2 levaria a um zoom em que nada mais e reconhecivel.
FOCO_MINIMO = 0.28


def enquadrar_foco(
    limites, alvo, *, vizinhanca: float = FOCO_VIZINHANCA, minimo: float = FOCO_MINIMO
):
    """Retangulo em volta de ``alvo``, com vizinhanca e preso dentro de ``limites``.

    Devolve `None` quando nao ha o que focar, e ai o chamador segue com o
    enquadramento do recorte inteiro.

    ``vizinhanca`` (quantas vezes o tamanho do alvo) e ``minimo`` (fracao do
    recorte) vêm calibrados para PE: 185 municípios num estado largo. No DF,
    com 35 RAs num recorte compacto, os mesmos valores deixavam 13 RAs sem
    aproximação nenhuma ao clique — o DFTB passa os seus (1,4 e 0,14).
    """
    if alvo is None:
        return None

    ax0, ay0, ax1, ay1 = alvo
    x0, y0, x1, y1 = limites
    largura_recorte, altura_recorte = x1 - x0, y1 - y0

    lado = max(
        (ax1 - ax0) * vizinhanca,
        (ay1 - ay0) * vizinhanca,
        largura_recorte * minimo,
        altura_recorte * minimo,
    )
    cx, cy = (ax0 + ax1) / 2, (ay0 + ay1) / 2
    meia = lado / 2

    # Preso dentro do recorte: um municipio na borda puxaria o enquadramento
    # para fora do estado, e sobraria oceano ou territorio vizinho sem dado.
    meia_x = min(meia, largura_recorte / 2)
    meia_y = min(meia, altura_recorte / 2)
    cx = min(max(cx, x0 + meia_x), x1 - meia_x)
    cy = min(max(cy, y0 + meia_y), y1 - meia_y)
    return (cx - meia_x, cy - meia_y, cx + meia_x, cy + meia_y)


def destacar_ilhas(dados, limites, indices):
    """Move ilhas oceanicas para um quadro no canto, fora de escala.

    Devolve o ``dados`` com a geometria das feicoes de ``indices`` substituida
    por uma copia ampliada e reposicionada, mais o retangulo do quadro.

    **Por que mover em vez de abrir uma segunda vista.** O deck.gl desenha
    varias `MapView` no mesmo canvas, e seria o certo, mas o componente do
    Streamlit gerencia o estado da vista por conta propria: le
    ``initialViewState.height`` para dimensionar o grafico e passa um
    controlador unico. Com duas vistas o mapa nao renderiza -- ``deck.gl:
    assertion failed`` em ``_rebuildViewports``. Testado.

    **Por que mover e honesto.** E o recurso classico dos atlas, e so vale
    acompanhado do aviso de que esta fora de escala -- por isso o quadro tem
    borda e rotulo. A alternativa era enquadrar a ilha junto, encolhendo o
    territorio em 37%, ou deixa-la fora da tela, somindo com um municipio que
    tem casos. Num painel de vigilancia, mapa incompleto e pior.

    A feicao movida conserta a geometria e **mantem as propriedades**, entao o
    clique continua entrando no municipio e o tooltip continua certo.
    """
    from shapely import affinity

    xmin, ymin, xmax, ymax = limites
    largura = xmax - xmin
    lado = largura * DESTAQUE_TAMANHO
    margem = largura * DESTAQUE_MARGEM

    quadro = (xmax - margem - lado, ymax - margem - lado, xmax - margem, ymax - margem)
    alvo_x = (quadro[0] + quadro[2]) / 2
    alvo_y = (quadro[1] + quadro[3]) / 2

    dados = dados.copy()
    ilhas = dados.loc[indices]
    ix0, iy0, ix1, iy1 = ilhas.total_bounds
    extensao = max(ix1 - ix0, iy1 - iy0) or 1e-9
    fator = (lado * 0.72) / extensao

    for i in indices:
        g = dados.at[i, "geometry"]
        g = affinity.scale(g, xfact=fator, yfact=fator, origin="center")
        cx, cy = g.centroid.x, g.centroid.y
        dados.at[i, "geometry"] = affinity.translate(g, alvo_x - cx, alvo_y - cy)

    return dados, quadro


def enquadrar(
    limites: tuple[float, float, float, float],
    *,
    largura: int = LARGURA_PAINEL,
    altura: int = ALTURA,
) -> dict:
    """Centro e zoom para o bounding box caber no painel.

    O deck.gl não expõe `fitBounds` no spec JSON, então o zoom é calculado
    aqui. **Considera as duas dimensões do painel**, e não só a maior do
    bounding box: o painel é mais alto que largo, e uma geometria larga e
    baixa — Pernambuco é o caso extremo — desperdiçava metade da altura
    quando o ajuste era feito só pela maior extensão.

    A conta é a do Mercator: no zoom 0 os 360° de longitude ocupam 256px, e
    cada nível dobra. Fica o menor dos dois zooms possíveis, que é o que faz
    a geometria caber inteira.
    """
    xmin, ymin, xmax, ymax = limites

    # O centro vertical é a média em **Mercator**, não em graus. Para o
    # Brasil, que vai de -33,7° a +5,3°, a média aritmética cai 0,8° ao norte
    # do centro real da projeção — o bastante para Roraima e Amapá saírem
    # pela borda de cima depois que o enquadramento passou a ser justo.
    centro = {
        "lat": _mercator_inverso((_mercator(ymin) + _mercator(ymax)) / 2),
        "lon": (xmin + xmax) / 2,
    }

    dx, dy = xmax - xmin, ymax - ymin
    if dx <= 0 and dy <= 0:
        return {"center": centro, "zoom": 9.0}

    # A latitude precisa ir para unidades de Mercator antes de virar escala:
    # o mapa estica conforme se afasta do equador, e o Brasil vai de -33° a
    # +5°. Tratando grau de latitude como grau de longitude, a geometria
    # estouraria a borda de baixo nos recortes mais ao sul.
    dy_merc = abs(_mercator(ymax) - _mercator(ymin))

    escalas = []
    if dx > 0:
        escalas.append(largura / dx)
    if dy_merc > 0:
        escalas.append(altura / dy_merc)
    px_por_grau = min(escalas)

    # A folga é maior do que a conta pediria. O zoom do deck.gl não segue
    # exatamente este modelo de 256px por 360° — medido no navegador, ele
    # desenha cerca de 10% maior que o previsto —, e errar para o lado de
    # cortar a geometria é pior do que errar para o lado da margem.
    # Verificação final é olhar o mapa do Brasil inteiro na tela.
    # 512 e não 256: o deck.gl usa tile de 512px, ao contrário do Leaflet.
    # Com 256 o zoom saía um nível alto demais e o Brasil era cortado no
    # norte e no sul — foi assim que Roraima sumiu da tela.
    zoom = float(np.log2(px_por_grau * 360 / 512) - 0.05)
    return {"center": centro, "zoom": max(2.0, min(zoom, 11.0))}


def _extensao(limites) -> list[float]:
    """Largura e altura do retângulo, na mesma conta de :func:`enquadrar`.

    Graus de longitude e graus de **Mercator** — é com estes dois que o
    `mapa.js` refaz o zoom para a largura real da caixa.
    """
    xmin, ymin, xmax, ymax = limites
    return [round(xmax - xmin, 6), round(abs(_mercator(ymax) - _mercator(ymin)), 6)]


def _rgb(cor: str) -> list[int]:
    """`#RRGGBB` para `[r, g, b]`, que é como o deck.gl espera."""
    texto = cor.lstrip("#")
    return [int(texto[i : i + 2], 16) for i in (0, 2, 4)]


#: Casas decimais mantidas nas coordenadas enviadas ao navegador.
#:
#: A malha traz seis, o que é 11 cm de precisão. O mapa é desenhado em cerca de
#: 430px cobrindo um estado inteiro — em Minas, um pixel vale perto de 2 km. As
#: cinco casas restantes são exatidão que nunca chega à tela e que o payload
#: paga por inteiro: em MG são 0,62 MB, e arredondar tira 14%.
#:
#: Cinco casas, e não quatro: são 1,1 m, com folga para o modo detalhe, que
#: enquadra um único município. Quatro dariam 11 m, e ali isso já se aproxima
#: de um pixel.
CASAS_COORDENADA = 5


def _arredondar(o):
    """Arredonda recursivamente as coordenadas de uma geometria GeoJSON."""
    if isinstance(o, float):
        return round(o, CASAS_COORDENADA)
    if isinstance(o, (list, tuple)):
        return [_arredondar(x) for x in o]
    if isinstance(o, dict):
        return {k: _arredondar(v) for k, v in o.items()}
    return o


def geometrias_geojson(camada) -> list:
    """Geometrias da camada em GeoJSON, sem as propriedades.

    Converter a malha custa 75 ms em Minas Gerais e é o item mais caro de
    montar o mapa — mais que todas as leituras de dado somadas. O resultado é
    idêntico entre renderizações: a geometria não muda quando o usuário troca
    de métrica ou de ano, só as cores mudam.

    Fica separado de :func:`deck` para o chamador poder memoizar. **Só a
    geometria** — propriedade carrega cor e valor, que mudam a cada interação,
    e guardar junto serviria mapa velho.

    As coordenadas são arredondadas a :data:`CASAS_COORDENADA`. A malha vem com
    seis casas, precisão de 11 centímetros, num mapa onde um pixel vale
    quilômetros — é peso que atravessa a rede sem chegar aos olhos de ninguém.
    """
    bruto = [f["geometry"] for f in camada[["geometry"]].__geo_interface__["features"]]
    return [_arredondar(g) for g in bruto]


def _compactar(mapa_deck) -> None:
    """Faz o deck serializar sem indentação.

    O `pydeck.serialize` chama ``json.dumps(..., indent=2)``, e o
    ``st.pydeck_chart`` envia ao navegador exatamente o que ``to_json()``
    devolver. Com a geometria aninhada em listas de coordenadas, essa
    indentação é a maior parte do que trafega: em Minas Gerais, com 853
    municípios, são 2,76 MB dos quais 2,0 MB são espaço em branco.

    E não é custo só da primeira carga — as cores fazem parte do mesmo spec,
    então o mosaico inteiro volta pela rede a cada navegação e a cada troca
    de métrica.

    Substituir o método na instância é feio, mas é o único ponto de entrada:
    o Streamlit não expõe opção de serialização e o `pydeck` não parametriza
    o `indent`. Se a API interna do pydeck mudar, o `except` devolve o
    comportamento padrão — payload grande, nunca página quebrada.
    """
    try:
        import json

        from pydeck.bindings.json_tools import default_serialize

        # `allow_nan=False`: um `NaN` perdido tem de **estourar aqui**, onde dá
        # para ver, e não chegar ao navegador como JSON inválido e deixar o
        # mapa parado.
        compacto = json.dumps(
            mapa_deck,
            sort_keys=True,
            default=default_serialize,
            separators=(",", ":"),
            allow_nan=False,
        )
    # Só a API interna do pydeck pode mudar sem aviso — nesse caso o payload
    # fica grande, nunca a página quebrada. Dado inválido (`ValueError`)
    # **não** entra aqui: antes esta captura era `Exception` e escondia
    # justamente o `NaN`.
    except (ImportError, AttributeError):
        return

    mapa_deck.to_json = lambda: compacto


def _camada_rotulos(pydeck, dados):
    """Valor impresso sobre cada polígono, como no boletim do Ministério.

    O tooltip cobre a leitura interativa, mas some em toque e não sobrevive a
    uma captura de tela — que é como painel de vigilância circula em reunião e
    em relatório. O boletim do MS imprime o número em cada UF justamente por
    isso.

    Três decisões que não são óbvias:

    - **`representative_point`, não `centroid`.** O centroide de um polígono
      côncavo cai fora dele; o Amapá e o Maranhão põem o rótulo no vizinho.
      `representative_point` garante um ponto interno.
    - **`pickable=False`.** Sem isso a camada de texto intercepta o clique e
      mata o drill-down bem no meio de cada estado, que é onde as pessoas
      clicam.
    - **Placa branca sob o texto**, em vez de contorno. A rampa vai de laranja
      claro a marrom, e texto escuro sem placa some no topo da escala
      enquanto texto claro some na base.

    Sem rótulo para quem não tem dado: "—" sobre o mapa é ruído, e a ausência
    já é comunicada pela cor neutra e pela legenda.

    **Rótulo que colide não é exibido.** Na primeira versão todos entravam, e
    no Brasil isso produzia `13,914,8` — dois números encavalados lendo como
    um só — mais sete rótulos empilhados no Nordeste. O deck.gl não faz
    *declutter*, então é feito aqui: os polígonos entram do maior para o
    menor, cada um reserva a área do seu rótulo, e quem cair sobre área já
    reservada fica de fora.

    A ordem por área é o que decide bem o desempate: o rótulo sobrevive onde
    há espaço para lê-lo. O valor de quem ficou de fora continua no tooltip.

    Cortar por limiar de área seria mais simples e pior — derrubaria o Rio de
    Janeiro, que é pequeno no mapa e dos mais relevantes na doença, mesmo
    quando ninguém disputa aquele espaço.
    """
    com_valor = dados[dados["valor"].notna()]
    if com_valor.empty:
        return None

    minx, miny, maxx, maxy = dados.total_bounds
    largura, altura = (maxx - minx) or 1.0, (maxy - miny) or 1.0

    # Área que um rótulo ocupa, em fração da extensão do mapa — a placa branca
    # conta, não só o texto. Calibrado contra a geometria real do Brasil: com
    # 0,045 x 0,022 nenhum par era detectado (Alagoas e Sergipe distam 1,0° na
    # vertical e a caixa tinha 0,86°), e todos os 27 continuavam colidindo na
    # tela. Com os valores abaixo ficam 23, e saem AL, PB, RN e DF — que é
    # exatamente o aglomerado ilegível. Rio de Janeiro, Sergipe e Piauí são
    # pequenos mas sobrevivem, porque ninguém disputa o espaço deles.
    meia_larg = largura * 0.070 / 2
    meia_alt = altura * 0.034 / 2

    # Tudo de uma vez, e não um `representative_point()` por iteração: em
    # polígono de UF a operação é cara, e chamada 27 vezes dentro do laço ela
    # sozinha levava o tempo de montar o mapa do Brasil de 203 ms para 528 ms
    # — mais que o mapa de Minas Gerais inteiro, com 853 municípios.
    pontos = com_valor.geometry.representative_point()
    # Ordena por área do bounding box calculada dos próprios limites, e não
    # por `.area` da geometria: em CRS geográfico o geopandas emite um aviso a
    # cada chamada ("results are likely incorrect"), e o mapa é redesenhado a
    # cada interação — o log de produção viraria só isso. Aqui a área serve só
    # para desempatar quem fica com o rótulo, então grau ao quadrado basta.
    lim = com_valor.geometry.bounds
    ordem = (
        ((lim["maxx"] - lim["minx"]) * (lim["maxy"] - lim["miny"]))
        .sort_values(ascending=False)
        .index
    )

    fonte: list[dict] = []
    ocupados: list[tuple[float, float, float, float]] = []
    for idx in ordem:
        ponto = pontos.loc[idx]
        x, y = float(ponto.x), float(ponto.y)
        caixa = (x - meia_larg, y - meia_alt, x + meia_larg, y + meia_alt)
        if any(
            caixa[0] < ox2 and caixa[2] > ox1 and caixa[1] < oy2 and caixa[3] > oy1
            for ox1, oy1, ox2, oy2 in ocupados
        ):
            continue
        ocupados.append(caixa)
        fonte.append({"posicao": [x, y], "texto": com_valor["exibicao"].loc[idx]})

    return pydeck.Layer(
        "TextLayer",
        character_set=_caracteres(d["texto"] for d in fonte),
        data=fonte,
        get_position="posicao",
        get_text="texto",
        # Nada de `size_units="pixels"`: o pydeck converte string solta em
        # acessor de dados (`@@=pixels`), o deck.gl recebe unidade inválida e
        # o texto passa a escalar com o zoom, virando garrafal. O default do
        # deck.gl já é pixels. Quando um literal for mesmo necessário, ele vai
        # entre aspas internas — como em `get_text_anchor` abaixo.
        get_size=11,
        get_color=[17, 24, 39],
        background=True,
        get_background_color=[255, 255, 255, 225],
        background_padding=[3, 1, 3, 1],
        get_text_anchor="'middle'",
        get_alignment_baseline="'center'",
        pickable=False,
    )


#: Estilo MapLibre sem fontes nem camadas: tela em branco atrás dos polígonos.
#:
#: Como URL `data:` e não como dict: o Streamlit faz `mapStyle.indexOf(...)`
#: no navegador e quebra com objeto. O MapLibre busca a URL como qualquer
#: outra, e o navegador resolve `data:` sem ir à rede.
ESTILO_SEM_FUNDO = 'data:application/json,{"version":8,"sources":{},"layers":[]}'


#: Linha dos estados por cima dos municípios: escura, e mais grossa que a divisa
#: municipal, pra ler o estado sem o mapa virar grade.
COR_DIVISA = (31, 41, 55, 200)
LARGURA_DIVISA = 1.2


@dataclass(frozen=True)
class Contornos:
    """Divisas e realce da camada de geografia — a parte do mapa que é **casca**.

    Cada painel tem a sua: o hansepe desenha a divisa em lilás acinzentado do
    meio da rampa, o DFTB em vinho, e aqui ela é branca translúcida. O
    desenho é o mesmo; só as cores mudam, por isso entram como parâmetro de
    :func:`deck` e não como constante do módulo. O padrão é o visual do tbpe.

    ``sem_dado`` é o contorno de quem não tem valor. ``None`` usa o
    ``padrao``. O hansepe e o DFTB o querem **escuro**: o preenchimento
    cinza de "sem dado" não se separa da faixa mais clara da rampa na
    tritanopia (ΔE 6,1 no hansepe), e um traço escuro é outro canal, que
    nenhum daltonismo apaga.

    ``realcado``, ``apagado`` e ``preenchimento_apagado`` só valem com uma
    faixa da legenda escolhida (``faixa_realcada``): a faixa fica com a cor e
    um traço escuro, o resto vai a cinza **chapado** — cinza, e não a mesma
    cor desbotada, porque a faixa mais baixa é o tom mais claro da rampa e
    contra o resto desbotado não se distinguia de nada (hansepe, 30/set).
    """

    padrao: tuple[int, ...] = (255, 255, 255, 150)
    sem_dado: tuple[int, ...] | None = None
    realcado: tuple[int, ...] = (17, 24, 39, 235)
    apagado: tuple[int, ...] = (205, 208, 214, 180)
    preenchimento_apagado: tuple[int, ...] = (226, 228, 233)
    largura: float = 0.6
    largura_realce: float = 1.1


def deck(
    camada,
    valores: pd.Series,
    *,
    chave: str,
    rampa: list[str],
    rotulo_metrica: str,
    coluna_nome: str,
    decimais: int = 1,
    altura: int = ALTURA,
    largura: int = LARGURA_PAINEL,
    foco_vizinhanca: float = FOCO_VIZINHANCA,
    foco_minimo: float = FOCO_MINIMO,
    geometrias: list | None = None,
    rotulos_valor: bool = False,
    destacado: str | None = None,
    metodo: str = "NATURAL",
    cortes_fixos: list[float] | None = None,
    nomes_fixos: tuple[str, ...] | None = None,
    casas_regua: int = 2,
    quantis: int = QUANTIS,
    detalhes: list[tuple[str, pd.Series, str, int]] | None = None,
    notas: pd.Series | None = None,
    faixa_realcada: str | None = None,
    contornos: Contornos = Contornos(),
    quadro_ilhas: bool = True,
    categorias: dict[str, str] | None = None,
    divisas: list | None = None,
):
    """Mapa em pydeck, para o drill-down por clique.

    ``divisas`` são geometrias (a saída de :func:`geometrias_geojson`) traçadas
    por cima, só a linha e sem clique: os estados sobre os municípios.

    ``coluna_nome`` é a coluna da camada com o nome de cada geografia —
    ``nome_mun``, ``regiao``, ``bairro_nome``, a RA. Sem padrão: o antigo,
    ``"bairro_nome"``, era herança do RecifeTB e, nas camadas de PE, caía em
    silêncio para a chave, e o tooltip mostrava o código no lugar do nome.

    ``detalhes`` é a lista de linhas extras do tooltip, no formato do painel
    de origem — ``(rótulo, série indexada pela chave, cor, decimais)``. O
    título e a métrica pintada vêm sempre; estas são os componentes que
    dão contexto ao número (casos, curas, população).

    ``notas`` é texto livre por chave, numa linha a mais do tooltip só onde
    há nota — a de população pequena do RecifeTB. Texto, não HTML: é escapado.

    ``nomes_fixos`` liga a régua oficial na escala fixa (ver
    :func:`escala_fixa`), e ``casas_regua`` é com quantas decimais ela se
    escreve.

    ``altura`` e ``largura`` são as da caixa em que o mapa vai ser
    desenhado, em pixels: o enquadramento é calculado para elas.

    ``foco_vizinhanca`` e ``foco_minimo`` dizem quanto o clique aproxima
    (ver :func:`enquadrar_foco`); o padrão é o de PE.

    ``quantis`` vai para ``QUARTIL``: o padrão é cinco (PE); o RecifeTB usa
    quatro.

    ``faixa_realcada`` é um rótulo da escala: com ele, só a faixa fica com
    cor (a legenda clicável do hansepe e do DFTB). Rótulo que não existe na
    escala é ignorado. ``contornos`` dá as cores disso e das divisas.

    ``categorias`` (categoria → cor, na ordem da legenda) torna o mapa
    categórico: ``valores`` traz o texto da classe de cada geografia, e
    ``metodo``, cortes e rampa deixam de valer (ver :func:`escala_categorica`).

    ``quadro_ilhas`` põe a ilha oceânica num quadro no canto, ampliada e
    "fora de escala" (ver :func:`destacar_ilhas`) — o padrão, que serve a PE.
    Com ``False`` a ilha fica no lugar, fora do enquadramento: num mapa do
    país inteiro o quadro de Noronha roubava a atenção (tbbrasil).

    O coroplético do Plotly não emite evento de clique — ver
    docs/mapa-clique.md. O ``GeoJsonLayer`` do deck.gl faz *picking* por GPU,
    que é o caminho que sobrou.

    Devolve ``(deck, escala)``: a escala sai junto porque o deck.gl não desenha
    legenda, e ela é montada em HTML por :func:`legenda`.
    """
    import pydeck

    colunas = list(dict.fromkeys([chave, coluna_nome if coluna_nome in camada else chave]))
    dados = camada[[*colunas, "geometry"]].copy()
    dados["valor"] = dados[chave].map(valores)

    escala_ = escala(
        dados["valor"],
        rampa,
        categorias=categorias,
        metodo=metodo,
        cortes_fixos=cortes_fixos,
        nomes_fixos=nomes_fixos,
        casas_regua=casas_regua,
        decimais=decimais,
        quantis=quantis,
    )
    # Faixa que não existe nesta escala não apaga ninguém: o rótulo guardado
    # da última interação continua no `session_state` quando a métrica ou a
    # classificação muda, e sem esta linha o mapa inteiro sairia apagado
    # (hansepe).
    if faixa_realcada is not None and faixa_realcada not in escala_.cores:
        faixa_realcada = None

    dados["classe"] = classificar(dados["valor"], escala_)
    dados["cor"] = dados["classe"].map(
        lambda c: _rgb(escala_.cores.get(c, SEM_DADO))
        if faixa_realcada in (None, c)
        else list(contornos.preenchimento_apagado)
    )

    # Contorno sempre por feição: "sem dado" pode querer o seu, haja ou não
    # faixa escolhida.
    def _contorno(classe: str) -> list[int]:
        if classe == ROTULO_SEM_DADO and contornos.sem_dado is not None:
            return list(contornos.sem_dado)
        if faixa_realcada is None:
            return list(contornos.padrao)
        return list(contornos.realcado if classe == faixa_realcada else contornos.apagado)

    dados["contorno"] = dados["classe"].map(_contorno)
    # Categórica: o valor já é o texto ("Prioridade alta"), e o tooltip o
    # mostra como veio.
    dados["exibicao"] = dados["valor"].map(
        lambda v: "—" if pd.isna(v)
        else str(v) if escala_.categorica else _formatar(float(v), decimais)
    )
    dados["rotulo"] = dados[colunas[-1]].astype(str)
    # `NaN` não é JSON: o Python o escreve como `NaN` e o `JSON.parse` do
    # componente levanta — o mapa então **mantém o desenho anterior**, e só a
    # legenda (que vem do Python) troca. Acontecia com Cura em toda
    # macrorregião e região de saúde, onde a geometria memoizada monta as
    # propriedades por `to_dict` e não pelo `to_json` do geopandas, que já
    # escrevia `null`. Ausente é `null`. Vem depois de `classe` e `exibicao`,
    # que precisam do `NaN` para dar "sem dado" e "—".
    dados["valor"] = dados["valor"].astype(object).where(dados["valor"].notna(), None)
    # Cada linha extra do tooltip entra como **valor** já formatado (`d0`,
    # `d1`, …), e rótulo e cor — iguais para todas as feições — ficam no
    # template.
    #
    # O componente **não escapa** o que vem das propriedades: `mapa.js`
    # substitui `{campo}` pelo valor cru e o tooltip é HTML. (Escapava no
    # `st.pydeck_chart`, e um comentário daqui dizia isso até 14/out.) Por isso
    # o que é texto livre, como as notas, é escapado aqui.
    for i, (_, serie, _, casas) in enumerate(detalhes or []):
        dados[f"d{i}"] = dados[chave].astype(str).map(
            lambda k, serie=serie, casas=casas: (
                "—" if serie.get(k) is None or pd.isna(serie.get(k))
                else _formatar(float(serie.get(k)), casas)
            )
        )
    # Uma linha a mais só onde há nota. O `<br>` vai dentro do valor: com ele
    # no template, quem não tem nota ganhava uma linha vazia (RecifeTB).
    if notas is not None:
        from html import escape

        dados["nota"] = dados[chave].map(notas).map(
            lambda t: f"<br><span style='opacity:.85'>{escape(t)}</span>"
            if isinstance(t, str) and t else ""
        )

    limites, ilhas = limites_uteis(camada)

    # Sem o quadro, a ilha é um município como outro qualquer: fica onde está
    # (fora do enquadramento, que continua a ignorá-la) e o clique nela
    # aproxima como em qualquer um. No Brasil inteiro o quadro de Fernando de
    # Noronha chamava mais atenção que qualquer capital (tbbrasil).
    if not quadro_ilhas:
        ilhas = []

    # Destaque tambem aproxima. Sem isso, um municipio pequeno acende como um
    # contorno de tres pixels no meio do estado e a pergunta "onde fica"
    # continua sem resposta.
    #
    # A ilha e a excecao: ela ja aparece ampliada no quadro do canto, e
    # aproximar nela levaria o enquadramento para o oceano.
    foco = None
    if destacado is not None and destacado not in {str(i) for i in ilhas}:
        alvo = dados[dados[chave].astype(str) == str(destacado)]
        if not alvo.empty and str(destacado) not in {
            str(camada.loc[i, chave]) for i in ilhas
        }:
            foco = enquadrar_foco(
                limites, tuple(alvo.total_bounds),
                vizinhanca=foco_vizinhanca, minimo=foco_minimo,
            )

    # Enquadra para a caixa **de verdade**. Até o 0.3.0 isto chamava
    # `enquadrar(foco or limites)` e a caixa era sempre a padrão, 580 × 530,
    # qualquer que fosse a `altura` pedida: o tbpe e o hansepe desenham em
    # 640, o RecifeTB em 720 e o DFTB em 400. Em PE quase não aparecia,
    # porque o estado é largo e quem limita é a largura; no DF de 400 px o
    # recorte saía cortado. O DFTB passava a altura — veio de lá.
    quadro = enquadrar(foco or limites, largura=largura, altura=altura)

    # A ilha vai para o canto **antes** de virar GeoJSON, para que o clique,
    # o tooltip e a cor sigam a feicao movida sem tratamento especial.
    #
    # Isto invalida a geometria memoizada pelo chamador, que foi feita a
    # partir da camada crua -- por isso o caminho rapido e desligado quando
    # ha ilha. Custa uma conversao a mais so nas UFs que tem uma, hoje so PE.
    #
    # **Só sem foco.** Com um município destacado o enquadramento é a
    # vizinhança dele, no meio do estado — e o quadro da ilha, posto no canto
    # dessa janela, caía em cima de outros municípios com o rótulo "fora de
    # escala" por cima da terra. Nesse caso a ilha fica onde está (fora da
    # tela, a leste); quem quiser vê-la volta ao recorte inteiro.
    moldura = None
    if ilhas and foco is None:
        dados, moldura = destacar_ilhas(
            dados, extensao_visivel(limites, largura=largura, altura=altura), ilhas
        )
        geometrias = None

    # As geometrias chegam prontas quando o chamador as memoizou; as
    # propriedades são sempre montadas do zero, porque carregam a cor.
    if geometrias is not None and len(geometrias) == len(dados):
        propriedades = dados.drop(columns="geometry").to_dict("records")
        colecao = {
            "type": "FeatureCollection",
            "features": [
                {"type": "Feature", "geometry": g, "properties": p}
                for g, p in zip(geometrias, propriedades, strict=True)
            ],
        }
    else:
        # Arredonda aqui também, para os dois caminhos desenharem a mesma
        # geometria — `tests/test_mapa.py` prende isso.
        #
        # **Só a geometria.** Arredondar a coleção inteira alcançaria também o
        # `valor` das propriedades, que alimenta o tooltip: 39,100684 virava
        # 39,10068 num caminho e não no outro.
        colecao = dados.__geo_interface__
        for feicao in colecao["features"]:
            feicao["geometry"] = _arredondar(feicao["geometry"])

    camada_geo = pydeck.Layer(
        "GeoJsonLayer",
        # `id` fixo: é o que deixa o deck.gl reconhecer a camada de um rerun
        # para o outro e **interpolar a cor** em vez de trocar de vez. Sem
        # ele o pydeck sorteia um id por instância e toda troca de métrica
        # é uma camada nova. Só faz efeito no componente próprio
        # (`mapa_componente`); no `st.pydeck_chart` é inerte.
        id="geografia",
        transitions={"getFillColor": TRANSICAO_COR_MS},
        data=colecao,
        get_fill_color="properties.cor",
        get_line_color="properties.contorno",
        line_width_min_pixels=(
            contornos.largura_realce if faixa_realcada is not None else contornos.largura
        ),
        stroked=True,
        filled=True,
        # `pickable` é o que faz o clique existir; `auto_highlight` dá o
        # retorno visual que o hover do Plotly dava de graça.
        pickable=True,
        auto_highlight=True,
        highlight_color=[255, 255, 255, 60],
    )

    camadas = [camada_geo]

    if divisas:
        camadas.append(pydeck.Layer(
            "GeoJsonLayer",
            data={"type": "FeatureCollection", "features": [
                {"type": "Feature", "properties": {}, "geometry": g} for g in divisas]},
            id="divisas", stroked=True, filled=False, pickable=False,
            get_line_color=list(COR_DIVISA), line_width_min_pixels=LARGURA_DIVISA,
        ))

    if moldura is not None:
        x0, y0, x1, y1 = moldura
        camadas.append(
            pydeck.Layer(
                "PolygonLayer",
                data=[{"poligono": [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]}],
                get_polygon="poligono",
                filled=False,
                stroked=True,
                get_line_color=[120, 120, 120, 170],
                line_width_min_pixels=1,
                # A moldura nao pode roubar o clique da ilha que ela emoldura.
                pickable=False,
            )
        )
        nomes = ", ".join(str(n) for n in dados.loc[ilhas, colunas[-1]])
        camadas.append(
            pydeck.Layer(
                "TextLayer",
                character_set=_caracteres([f"{nomes} (fora de escala)"]),
                # Ancorado na borda **direita** do quadro, crescendo para a
                # esquerda: centrado, metade do texto saía pelo lado direito
                # do canvas — o quadro fica no canto, e "Fernando de Noronha
                # (fora de escala)" é mais largo que ele.
                data=[{"posicao": [x1, y0], "texto": f"{nomes} (fora de escala)"}],
                get_position="posicao",
                get_text="texto",
                get_size=10,
                # Escuro sobre uma lapela branca (hansepe). O cinza médio de
                # antes dava 4,17:1 no tema claro e 3,21:1 no escuro, contra o
                # mínimo de 4,5:1 para 10px — e não existe cinza que passe
                # nos dois: o canvas é transparente, o fundo do texto é a
                # superfície do tema. A lapela tira o texto dessa dependência.
                get_color=[17, 24, 39],
                background=True,
                get_background_color=[255, 255, 255, 225],
                background_padding=[3, 1, 3, 1],
                get_alignment_baseline="'top'",
                get_text_anchor="'end'",
                pickable=False,
            )
        )

    if rotulos_valor:
        rotulos = _camada_rotulos(pydeck, dados)
        if rotulos is not None:
            camadas.append(rotulos)

    if destacado is not None:
        camadas += _camadas_destaque(pydeck, dados, chave, destacado, colunas[-1])

    mapa_deck = pydeck.Deck(
        layers=camadas,
        initial_view_state=pydeck.ViewState(
            latitude=quadro["center"]["lat"],
            longitude=quadro["center"]["lon"],
            zoom=quadro["zoom"],
            bearing=0,
            pitch=0,
            height=altura,
            # O tamanho do que foi enquadrado (graus de longitude, graus de
            # Mercator) e a largura que o zoom supôs. O Python não sabe a
            # largura real da coluna; o `mapa.js` sabe, e com estes dois
            # refaz o zoom quando a caixa é mais estreita — numa janela de
            # 960 px o Brasil saía cortado no Norte (tbbrasil).
            extensao=_extensao(foco or limites),
            largura=largura,
            # Sem `transition_duration` nem `FlyToInterpolator`: o pydeck
            # emite os dois, e eles não fazem nada aqui. Medido no navegador —
            # o Streamlit **recria o contêiner e o canvas do deck a cada
            # rerun**, inclusive quando a `key` do widget não muda. Sem
            # instância anterior não há câmera de onde partir, e
            # `initialViewState` é sempre inicial de fato.
        ),
        map_provider=None,
        # **Sem mapa de fundo**, como no painel de origem. `map_style=None`
        # não basta: o Streamlit faz `mapStyle ||= <Carto positron/dark>` no
        # navegador e desenha um basemap com rótulos de estados vizinhos em
        # volta de PE. Um estilo MapLibre vazio é "verdadeiro" para esse
        # `||=` e não desenha nada — é o único jeito de dizer "nenhum". Entra
        # depois do construtor, abaixo: o pydeck só aceita dict de estilo com
        # `map_provider="mapbox"`, que puxaria o Mapbox de volta.
        map_style=None,
        # Formato do painel de origem: título, a métrica pintada em destaque
        # e, abaixo, os componentes com a bolinha na cor de cada métrica.
        tooltip={
            "html": (
                "<div style='font-weight:700;font-size:13px'>{rotulo}</div>"
                f"<div style='opacity:.85;margin-bottom:4px'>{rotulo_metrica}: "
                "<b>{exibicao}</b>" + ("{nota}" if notas is not None else "") + "</div>"
                + _template_detalhes(detalhes or [])
            ),
            "style": {
                "backgroundColor": "rgba(17,24,39,.96)",
                "color": "#fff",
                "fontSize": "12px",
                "borderRadius": "10px",
                "padding": "8px 10px",
                "lineHeight": "1.5",
                # A nota é texto corrido ("população abaixo de 5 mil: taxa
                # instável"); sem teto, o tooltip esticava numa linha só.
                **({"maxWidth": "260px"} if notas is not None else {}),
            },
        },
    )

    mapa_deck.map_style = ESTILO_SEM_FUNDO
    _compactar(mapa_deck)

    # O zoom pela roda do mouse é desligado no componente (`scrollZoom: false`
    # em `mapa.js`); o `script_travar_zoom`, que fazia isso para o
    # `st.pydeck_chart`, saiu em 21/set.

    return mapa_deck, escala_


#: Duração da interpolação de cor dos polígonos ao trocar métrica, ano ou
#: classificação, em ms. Mais curta que o voo da câmera (`mapa_componente.
#: TRANSICAO_MS`): cor que demora a assentar parece dado carregando.
TRANSICAO_COR_MS = 450


#: Espessura das duas linhas do destaque, em pixels. A de baixo e branca e
#: mais larga, a de cima e escura -- o par funciona sobre qualquer tom da
#: rampa, que vai de creme a quase preto. Uma linha so sumiria numa ponta ou
#: na outra.
DESTAQUE_HALO = 5
DESTAQUE_TRACO = 2


def _camadas_destaque(pydeck, dados, chave, destacado, coluna_nome):
    """Contorno e nome do municipio apontado pelo clique na barra.

    Nao pinta o interior: a cor da feicao e o dado, e sobrepor tinta ali
    esconderia justamente o que o mapa esta dizendo. O destaque e um contorno
    e um nome, e nada mais.
    """
    alvo = dados[dados[chave].astype(str) == str(destacado)]
    if alvo.empty:
        return []

    colecao = {
        "type": "FeatureCollection",
        "features": [
            {"type": "Feature", "geometry": _arredondar(f["geometry"]), "properties": {}}
            for f in alvo.__geo_interface__["features"]
        ],
    }

    def contorno(cor, largura):
        return pydeck.Layer(
            "GeoJsonLayer",
            data=colecao,
            filled=False,
            stroked=True,
            get_line_color=cor,
            line_width_min_pixels=largura,
            # Nao pode roubar o clique de quem esta embaixo, que e a propria
            # feicao destacada -- o mapa continua servindo para entrar nela.
            pickable=False,
        )

    camadas = [
        contorno([255, 255, 255, 235], DESTAQUE_HALO),
        contorno([17, 24, 39, 245], DESTAQUE_TRACO),
    ]

    # A etiqueta traz nome **e** valor, e nao so o nome.
    #
    # O contorno ja diz onde; o que falta e quanto, que e a pergunta do painel.
    # Sem o valor, quem destaca um municipio tem de procurar a barra dele no
    # ranking para saber o numero -- ida e volta que a etiqueta resolve.
    #
    # `font_weight` saiu: a camada de rotulos de valor, que funciona ha
    # semanas, nao usa, e a diferenca entre as duas era essa mais o
    # alinhamento. Nao vale carregar uma propriedade a mais numa camada que
    # precisa ser legivel acima de tudo.
    centro = alvo.geometry.iloc[0].centroid
    nome = str(alvo.iloc[0][coluna_nome])
    exibicao = alvo.iloc[0].get("exibicao")
    texto = f"{nome}  {exibicao}" if exibicao not in (None, "", "\u2014") else nome
    camadas.append(
        pydeck.Layer(
            "TextLayer",
            character_set=_caracteres([texto]),
            data=[{"posicao": [centro.x, centro.y], "texto": texto}],
            get_position="posicao",
            get_text="texto",
            # 14 contra os 11 dos rotulos de valor: a etiqueta e uma so na
            # tela, entao pode ser maior sem virar poluicao, e ela precisa se
            # destacar do proprio mapa que esta anotando.
            get_size=14,
            get_color=[17, 24, 39, 255],
            get_text_anchor="'middle'",
            get_alignment_baseline="'center'",
            get_pixel_offset=[0, -22],
            background=True,
            get_background_color=[255, 255, 255, 235],
            background_padding=[6, 3, 6, 3],
            get_border_color=[17, 24, 39, 180],
            get_border_width=1,
            pickable=False,
        )
    )
    return camadas


def _template_detalhes(detalhes) -> str:
    """Trecho do template do tooltip com as linhas extras.

    Cada linha é ``● rótulo  {dN}``, com a bolinha na cor da métrica, como
    no painel de origem. Só o valor é interpolado pelo deck; rótulo e cor
    são estáticos porque são os mesmos para toda feição.
    """
    from html import escape

    return "".join(
        f"<div style='display:flex;justify-content:space-between;gap:14px'>"
        f"<span><i style='display:inline-block;width:8px;height:8px;"
        f"border-radius:50%;background:{cor};margin-right:6px'></i>"
        f"{escape(rotulo)}</span><b>{{d{i}}}</b></div>"
        for i, (rotulo, _, cor, _) in enumerate(detalhes)
    )


def legenda(
    escala: Escala,
    titulo: str,
    contagem: pd.Series | None = None,
    nomes: tuple[str, ...] | None = None,
) -> str:
    """Legenda em HTML — o deck.gl não desenha uma.

    ``contagem`` (rótulo → n) põe ao lado de cada faixa quantas unidades
    caem nela — substitui a tabela "regiões por classe" do painel de origem,
    que repetia as faixas da legenda só para acrescentar o N. ``nomes`` dá
    a cada classe o nome que a régua oficial usa ("baixa", "hiperendêmica"),
    quando a escala é fixa e tem nome.
    """
    from html import escape

    def texto(i: int, r: str) -> str:
        partes = [escape(r)]
        if nomes and i < len(nomes):
            partes.append(f"<em>{escape(nomes[i])}</em>")
        if contagem is not None:
            partes.append(f"<b>{int(contagem.get(r, 0))}</b>")
        return " &nbsp;".join(partes)

    rotulos = [*escala.rotulos, ROTULO_SEM_DADO]
    itens = "".join(
        f'<span class="mapa-legenda-item">'
        f'<i style="background:{escape(escala.cores[r])}"></i>{texto(i, r)}</span>'
        for i, r in enumerate(rotulos)
        if r in escala.cores
        # "sem dado" só aparece quando há alguém sem dado.
        and (r != ROTULO_SEM_DADO or contagem is None or contagem.get(r, 0))
    )
    return (
        f'<div class="mapa-legenda">'
        f'<div class="mapa-legenda-titulo">{escape(titulo)}</div>{itens}</div>'
    )
