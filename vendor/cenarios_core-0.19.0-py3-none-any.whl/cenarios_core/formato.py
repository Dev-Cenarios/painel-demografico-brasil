"""Número escrito em português: ponto no milhar, vírgula no decimal.

Os gráficos montam o texto do tooltip no Python, porque o ECharts não formata
número por texto. As duas funções são as do tema dos painéis
(`theme/componentes.py`), iguais nos quatro.
"""

from __future__ import annotations


def formatar_inteiro(valor: float | None) -> str:
    """``12345.6`` → ``"12.346"``; ``None`` → ``"—"``."""
    if valor is None:
        return "—"
    return f"{valor:,.0f}".replace(",", ".")


def formatar_decimal(valor: float | None, casas: int = 2) -> str:
    """``1234.5`` → ``"1.234,50"``; ``None`` → ``"—"``."""
    if valor is None:
        return "—"
    texto = f"{valor:,.{casas}f}"
    return texto.replace(",", "\x00").replace(".", ",").replace("\x00", ".")
